"use client";
import { Loader2, Save, Volume2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useEffect, useState } from "react";
import getCurrentGuild from "@/app/actions/getCurrentGuild";
import { getGuildChannels } from "@/app/actions/guilds/getGuildChannels";
import { updateGuildSettings } from "@/app/actions/guilds/updateGuildSettings";
import { toast } from "sonner";
import { useRouter } from "next/navigation";

export const DiscordSettingsCard = ({
  serverId,
  serverData,
  guildChannels,
}: any) => {
  const router = useRouter();

  const [serverName, setServerName] = useState(serverData?.data?.dsData?.name);
  const [serverMsgNotificationSettings, setServerMsgNotificationSettings] =
    useState(0 || serverData?.data?.dsData?.defaultMessageNotifications);
  const [serverAfkChannelId, setServerAfkChannelId] = useState(
    0 || serverData?.data?.dsData?.afkChannelId,
  );
  const [serverAfkTimeout, setServerAfkTimeout] = useState(
    0 || serverData?.data?.dsData?.afkTimeout,
  );
  const [serverVerificationLevel, setServerVerificationLevel] = useState(
    serverData?.data?.dsData?.verificationLevel,
  );
  const [serverNsfwLevel, setServerNsfwLevel] = useState(
    serverData?.data?.dsData?.nsfwLevel,
  );

  console.log(
    serverName,
    serverMsgNotificationSettings,
    serverAfkChannelId,
    serverAfkTimeout,
    serverVerificationLevel,
    serverNsfwLevel,
  );

  const updateSettingsForGuild = async (setting: any, content: any) => {
    console.log(content);
    const response = await updateGuildSettings(serverId, setting, content);
    if (response === 200) {
      toast.success("Updated your server settings successfully.");
      router.refresh();
    }
  };

  if (serverData !== null) {
    return (
      <Card className="w-full h-[100%] bg-background p-2">
        <CardContent className="p-2 overflow-y-auto h-[100%]">
          <div className="flex flex-col gap-2 items-start w-full">
            <h4 className="text-xl text-left w-full font-bold text-foreground">
              General Settings
            </h4>
            <Label
              htmlFor="mymodLogChannel"
              className="text-muted-foreground text-sm w-full"
            >
              Due to Discord API limitations, some settings may not be displayed
              here, such as Community settings. Continue to use the Discord
              client to modify these settings.
            </Label>
            <div className="flex flex-col md:flex-row gap-1 items-start md:items-center justify-start w-full">
              <Label htmlFor="mymodLogChannel" className="text-muted-foreground w-[40%]">
                Server name
              </Label>
              <Input
                type="text"
                name="mymodLogChannel"
                placeholder="e.g: My Beautiful Server"
                onChange={(e) => setServerName(e.target.value)}
                value={serverName}
                className="bg-background text-foreground"
              />
              <Button
                variant="outline"
                size="icon"
                className="self-end md:self-start"
                onClick={() =>
                  updateSettingsForGuild("server_name", serverName)
                }
              >
                <Save />
              </Button>
            </div>
            <br />
            <Separator className="border-muted-foreground" />
            <br />
            <h4 className="text-xl text-left w-full font-bold text-foreground">
              Engagement
            </h4>
            <div className="flex flex-col md:flex-row gap-1 items-start md:items-center justify-start w-full">
              <Label
                htmlFor="mymodLogChannel"
                className="text-muted-foreground w-full md:w-[40%]"
              >
                Default Notification Settings
              </Label>
              <Select
                name="verification_level"
                onValueChange={(e) =>
                  setServerMsgNotificationSettings(Number.parseInt(e))
                }
                value={`${serverMsgNotificationSettings}`}
              >
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="Select a verification level..." />
                </SelectTrigger>
                <SelectContent side="bottom">
                  <SelectItem value="0">All Messages</SelectItem>
                  <SelectItem value="1">Only @mentions</SelectItem>
                </SelectContent>
              </Select>
              <Button
                variant="outline"
                size="icon"
                className="self-end md:self-start"
                onClick={() =>
                  updateSettingsForGuild(
                    "message_notification_settings",
                    serverMsgNotificationSettings,
                  )
                }
              >
                <Save />
              </Button>
            </div>
            <br />
            <div className="flex flex-row gap-2 justify-between items-center w-full">
              <div className="flex flex-col gap-1 items-start justify-center w-full">
                <Label htmlFor="mymodLogChannel" className="text-muted-foreground w-[40%]">
                  Inactive Channel
                </Label>
                <div className="flex flex-col md:flex-row gap-1 items-start md:items-center justify-start w-full">
                  <Select
                    name="verification_level"
                    onValueChange={(e) =>
                      setServerAfkChannelId(Number.parseInt(e))
                    }
                    value={`${serverAfkChannelId}`}
                  >
                    <SelectTrigger className="w-full">
                      <SelectValue placeholder="Select a verification level..." />
                    </SelectTrigger>
                    <SelectContent side="bottom">
                      <SelectItem value="null">None</SelectItem>
                      {guildChannels?.map((channel: any) => (
                        <SelectItem key={channel.id} value={channel.id}>
                          <Volume2 /> {channel.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <Button
                    variant="outline"
                    size="icon"
                    className="self-end md:self-start"
                    onClick={() =>
                      updateSettingsForGuild(
                        "afk_channel_id",
                        serverAfkChannelId,
                      )
                    }
                  >
                    <Save />
                  </Button>
                </div>
              </div>
              <div className="flex flex-col gap-1 items-start justify-center w-full">
                <Label htmlFor="mymodLogChannel" className="text-muted-foreground w-[40%]">
                  Inactive Timeout
                </Label>
                <div className="flex flex-col md:flex-row gap-1 items-start md:items-center justify-start w-full">
                  <Select
                    name="verification_level"
                    onValueChange={(e) =>
                      setServerAfkTimeout(Number.parseInt(e))
                    }
                    value={`${serverAfkTimeout}`}
                  >
                    <SelectTrigger className="w-full">
                      <SelectValue placeholder="Select a verification level..." />
                    </SelectTrigger>
                    <SelectContent side="bottom">
                      <SelectItem value="60">1 minute</SelectItem>
                      <SelectItem value="300">5 minutes</SelectItem>
                      <SelectItem value="900">15 minutes</SelectItem>
                      <SelectItem value="1800">30 minutes</SelectItem>
                      <SelectItem value="3600">1 hour</SelectItem>
                    </SelectContent>
                  </Select>
                  <Button
                    variant="outline"
                    size="icon"
                    className="self-end md:self-start"
                    onClick={() =>
                      updateSettingsForGuild("afk_timeout", serverAfkTimeout)
                    }
                  >
                    <Save />
                  </Button>
                </div>
              </div>
            </div>
            <br />
            <Separator className="border-muted-foreground" />
            <br />
            <h4 className="text-xl text-left w-full font-bold text-foreground">
              Moderation
            </h4>
            <h4 className="text-sm uppercase text-left w-full font-bold text-foreground/50">
              Safety Setup
            </h4>
            <div className="flex flex-col md:flex-row gap-1 items-center justify-between w-full">
              <div className="flex flex-col gap-1 items-start">
                <Label htmlFor="mymodLogChannel" className="text-foreground">
                  Verification level
                </Label>
                <Label
                  htmlFor="mymodLogChannel"
                  className="text-muted-foreground text-sm w-[80%]"
                >
                  Members of the server must meet the following criteria before
                  they can send messages in text channels, or initiate a DM. If
                  a member has an assigned role and server onboarding is not
                  enabled, this does not apply.
                </Label>
              </div>
              <Select
                name="verification_level"
                onValueChange={(e) => setServerVerificationLevel(e)}
                value={`${serverVerificationLevel}`}
              >
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="Select a verification level..." />
                </SelectTrigger>
                <SelectContent side="bottom" className="w-[70%] md:w-full">
                  <SelectItem
                    value="0"
                    className="border-l-2 rounded-none rounded-t-sm rounded-r-md border-zinc-500 text-wrap"
                  >
                    None - Unrestricted
                  </SelectItem>
                  <SelectItem
                    value="1"
                    className="border-l-2 rounded-none rounded-r-sm border-green-500 text-wrap"
                  >
                    Low - Must have a verified email on their account
                  </SelectItem>
                  <SelectItem
                    value="2"
                    className="border-l-2 rounded-none rounded-r-sm border-yellow-500 text-wrap"
                  >
                    Medium - Must be registered on Discord for longer than 5
                    minutes
                  </SelectItem>
                  <SelectItem
                    value="3"
                    className="border-l-2 rounded-none rounded-r-sm border-orange-500 text-wrap"
                  >
                    High - Must be a member of the server for longer than 10
                    minutes
                  </SelectItem>
                  <SelectItem
                    value="4"
                    className="border-l-2 rounded-none rounded-b-sm rounded-r-md border-red-500 text-wra"
                  >
                    Highest - Must have a verified phone number
                  </SelectItem>
                </SelectContent>
              </Select>
              <Button
                variant="outline"
                size="icon"
                onClick={() =>
                  updateSettingsForGuild(
                    "verification_level",
                    serverVerificationLevel,
                  )
                }
              >
                <Save />
              </Button>
            </div>
            <div className="flex flex-col md:flex-row gap-1 items-start md:items-center justify-between w-full">
              <div className="flex flex-col gap-1 items-start">
                <Label htmlFor="mymodLogChannel" className="text-foreground">
                  Explicit image filter
                </Label>
                <Label
                  htmlFor="mymodLogChannel"
                  className="text-muted-foreground text-sm max-w-[80%]"
                >
                  Automatically block messages in this server that may contain
                  explicit images in channels not marked as Age-restricted.
                  Please choose how this filter will apply to members in your
                  server.
                </Label>
              </div>
              <Select
                name="nsfw_level"
                onValueChange={(e) => setServerNsfwLevel(e)}
                value={`${serverNsfwLevel}`}
              >
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="Select your explicit image filter..." />
                </SelectTrigger>
                <SelectContent className="w-[70%] md:w-full">
                  <SelectItem value="0">Do not filter</SelectItem>
                  <SelectItem value="1">
                    Filter messages from server members without roles
                  </SelectItem>
                  <SelectItem value="2">
                    Filter messages from all members
                  </SelectItem>
                </SelectContent>
              </Select>
              <Button
                variant="outline"
                size="icon"
                onClick={() =>
                  updateSettingsForGuild("nsfw_level", serverNsfwLevel)
                }
              >
                <Save />
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  } else {
    return (
      <Card className="w-full bg-black border-zinc-700 flex flex-row items-center justify-center">
        <Loader2 className="animate-spin w-12 h-12 text-white" />
      </Card>
    );
  }
};
